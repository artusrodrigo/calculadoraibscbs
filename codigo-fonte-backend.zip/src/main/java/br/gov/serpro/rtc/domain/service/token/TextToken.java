/*
 * Versão de Homologação/Testes
 */
package br.gov.serpro.rtc.domain.service.token;

public final record TextToken (String text, String key){
}