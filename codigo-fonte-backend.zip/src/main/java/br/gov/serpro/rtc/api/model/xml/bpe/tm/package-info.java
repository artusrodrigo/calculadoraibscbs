//
// Este arquivo foi gerado pela Eclipse Implementation of JAXB, v4.0.5 
// Consulte https://eclipse-ee4j.github.io/jaxb-ri 
// Todas as modificações neste arquivo serão perdidas após a recompilação do esquema de origem. 
//

@XmlSchema(namespace = "http://www.portalfiscal.inf.br/bpe", elementFormDefault = XmlNsForm.QUALIFIED)
package br.gov.serpro.rtc.api.model.xml.bpe.tm;

import jakarta.xml.bind.annotation.XmlNsForm;
import jakarta.xml.bind.annotation.XmlSchema;
