package br.gov.serpro.rtc.api.model.xml;

public record TipoDocumentoDTO(String nome, String mnemonico, String versaoNotaTecnica) {
}
