/*
 * Versão de Homologação/Testes
 */
package br.gov.serpro.rtc.api.model.output.dadosabertos;

import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import br.gov.serpro.rtc.api.model.SerializationVisibility;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
@JsonInclude(Include.NON_NULL)
public class NbsDadosAbertosOutput implements SerializationVisibility {

    @Schema(name = "tributadoPeloImpostoSeletivo", description = "Tributado pelo Imposto Seletivo", example = "")
    private final boolean tributadoPeloImpostoSeletivo;

    @Schema(name = "aliquotaAdValorem", description = "Alíquota ad valorem do Imposto Seletivo", example = "")
    private final BigDecimal aliquotaAdValorem;

    // @Schema(name = "aliquotaAdRem", description = "Alíquota ad rem do Imposto Seletivo", example = "")
    // private final BigDecimal aliquotaAdRem;

    @Schema(name = "capitulo", description = "Capítulo da NBS", example = "")
    private final String capitulo;

    @Schema(name = "posicao", description = "Posição da NBS", example = "")
    private final String posicao;

    @Schema(name = "subposicao1", description = "Subposição 1 da NBS", example = "")
    private final String subposicao1;

    @Schema(name = "subposicao2", description = "Subposição 2 da NBS", example = "")
    private final String subposicao2;

    @Schema(name = "item", description = "Item da NBS", example = "")
    private final String item;

}
